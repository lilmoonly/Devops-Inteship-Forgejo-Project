// Copyright 2021 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package paginator

// dummy only. in the future, the models/db/list_options.go should be moved here to decouple from db package
// otherwise the unit test will cause cycle import
